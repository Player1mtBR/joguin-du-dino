/**
 * 
 */
/**
 * 
 */
module dinoChrome {
	requires java.desktop;
}